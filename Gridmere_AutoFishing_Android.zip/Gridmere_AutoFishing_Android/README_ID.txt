GRIDMERE AUTOFISHING ANDROID — KERANGKA AWAL

Isi:
- Proyek Android Studio Kotlin
- Izin MediaProjection untuk menangkap layar game
- AccessibilityService untuk mengirim gesture/tap/hold
- Tombol uji sentuhan di tengah layar

PENTING:
Ini BELUM autofishing otomatis yang siap dipakai. Ini adalah kerangka aplikasi Android.
Deteksi posisi ikan, kotak target, indikator progres, tombol lempar/tarik, dan koordinat kontrol
belum dikalibrasi karena dibutuhkan screenshot asli dari layar Android (bukan sekadar uraian kontrol).
Layanan tidak akan menekan tombol game secara otomatis.

Cara membuka:
1. Ekstrak ZIP.
2. Buka folder Gridmere_AutoFishing_Android di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Build > Build APK(s), atau jalankan ke perangkat.

Pengujian:
1. Instal aplikasi hasil build.
2. Buka aplikasi.
3. Tekan "Aktifkan Accessibility Service", lalu aktifkan Gridmere AutoFishing.
4. Kembali ke aplikasi dan tekan "Izinkan tangkapan layar".
5. Buka Gridmere. Tombol uji sentuhan hanya untuk memeriksa izin gesture; jangan gunakan saat bermain
   jika tidak ingin ada sentuhan di tengah layar.

Batasan teknis:
- MediaProjection menampilkan dialog izin Android dan harus diizinkan pengguna.
- Accessibility Service harus diaktifkan manual oleh pengguna.
- Android membatasi pengiriman input ke aplikasi lain; layanan ini memakai gesture sentuh,
  bukan menyuntikkan tombol keyboard.
- Beberapa ponsel mungkin menghentikan layanan saat hemat baterai aktif.
- Tidak ada root, pembacaan memori game, atau modifikasi file game.

Untuk menyelesaikan deteksi otomatis, kirim screenshot asli minigame dari HP yang memperlihatkan
ikan, kotak target, indikator progres, serta tombol kiri/kanan/tarik. Jika memungkinkan kirim
juga screenshot ketika kail menunggu sambaran dan ketika ikan menyambar. Tutupi informasi akun
jika terlihat.
