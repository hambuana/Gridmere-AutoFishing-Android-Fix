package com.gridmere.autofishing

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity

class MainActivity : Activity() {
    private val requestCapture = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply {
            text = "Gridmere AutoFishing • Android\n\nVersi kerangka awal. Aktifkan Accessibility Service, lalu izinkan tangkapan layar. Deteksi ikan/kotak masih perlu dikalibrasi dari screenshot minigame perangkatmu."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "1. Aktifkan Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "2. Izinkan tangkapan layar"
            setOnClickListener {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        })
        layout.addView(Button(this).apply {
            text = "3. Uji sentuhan tengah layar"
            setOnClickListener {
                FishingAccessibilityService.instance?.tap(
                    resources.displayMetrics.widthPixels / 2f,
                    resources.displayMetrics.heightPixels / 2f
                )
            }
        })
        layout.addView(Button(this).apply {
            text = "Hentikan layanan tangkapan"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API but used for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val svc = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            startForegroundService(svc)
        }
    }
}
